ViewPagerNoSwipe - source code
===============================

How to disable swipe/paging on ViewPager in Android

see complete tutorial at http://xtreamcoder.com/disable-swipe-in-android-viewpager/
